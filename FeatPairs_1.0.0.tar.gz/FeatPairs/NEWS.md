# FeatPairs 1.0.0

* Initial CRAN submission.
