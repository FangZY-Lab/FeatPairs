#' @title Find Variable Features with Variance-Stabilizing Transformation
#'
#' @description This function takes a count matrix input and returns a statistics table for features ranked in the descending order of stabilized variances.
#'
#' @param x features by samples/cells
#' @param eps.var a small positive value for variance failed to be estimated
#' @param span parameter for lowess fitting
#'
#' @return A table for features ranked in the descending order of stabilized variances, with three columns: average, variance, stabilized variance.
#'
aux_find_variable_features_vst = function(x,eps.var=0.01,span=0.3){
	x.mean = rowMeans(x)
	x.vars = matrixStats::rowVars(x)
	x.vars.expected = predict(loess(x.vars~x.mean,span=span),x.mean)
	x.vars.expected[is.na(x.vars.expected)] = eps.var
	x.vars.expected[x.vars.expected<0] = eps.var
	x.stand = (x - x.mean)/sqrt(x.vars.expected) #x.vars.expected <- x.vars

	std.max = sqrt(ncol(x))*10 #possible extreme values, loosen from Seurat by 10 fold
	x.stand[x.stand > std.max] = std.max
	x.stand[x.stand < -std.max] = -std.max

	x.stand.vars = matrixStats::rowVars(x.stand) #x.stand.vars <- x
	o = order(x.stand.vars,decreasing=T)
	stat = cbind(mean=x.mean[o], var=x.vars[o], var.standardized = x.stand.vars[o])
	return(stat)
}


#' @title Feature Pairs Method for a Count Data Matrix
#'
#' @description This function takes a count matrix input and returns a statistics table for features ranked in the descending order of stabilized variances.
#'
#' @param counts Raw count data (features x samples/cells), better after quality filtering in Seurat. Rare genes could be filtered before being used as input. Imputation is not necessary, though if already done set impute.ctrl.feats = FALSE and impute.ctrl.mods = FALSE.
#' @param logcounts Log (e base) transformed sequencing-depth-normalized counts
#' @param n.ctrl.feats Number of control features
#' @param n.ctrl.mods Number of control modules
#' @param ctrl.mods A list of control modules
#' @param n.ctrl.nn Number of nearest neighbours for each control feature as an extension
#' @param minsize.ctrl.mod Minimal size of a control module
#' @param n.var.feats Number of highly variable features to keep after obtaining feature pairs 
#' @param span Parameter for lowess fitting
#' @param adjust.modcount Logical, whether to perform a simple standardization of module counts to make the pair ratios based on different modules more comparable. If use.snn, they should become comparable anyway, so this adjustment is not needed (but still can be done, even though no impact on SNN).
#' @param adjust.dist.scale  Logical, whether to perform a rank-based standardization on distance matrices from pair ratios based on different control modules to make them more comparable in scale.
#' @param impute.ctrl.feats Logical, whether or not to perform imputation on control features. Since some ctrl features also have zeros, although pseudo counts will be added, an explicit imputation for the zeros might be helpful in some cases (with risk of distortion on the correlation structure of data).
#' @param impute.ctrl.mods Logical, whether or not to perform imputation on control modules. Might be needed in certain cases with very severe dropout so that still lots of 0s even in the summarized module count of these control modules.
#' @param method.impute Imputation method, either 'knn' or 'saver' 
#' @param pca Logical, whether perform PCA dimension reduction after obtaining feature pairs 
#' @param pca.ndim The dimensions of PCA to use 
#' @param pca.dim1 The start dimension of PCA to use, usually 1
#' @param pca.scale Logical, whether to perform scaling before PCA
#' @param use.snn Logical, whether generating shared nearest neighbour (SNN) networks
#' @param k.snn Number of k for kNN used by SNN. Seurat uses 20 as default. A larger k could also be used in terms of visualization smoothness.
#' @param k.impute Number of nearest-neighbour cells for imputation with kNN on features.
#' @param parallel Logical, whether to use parallel computing
#' @param eps.cnt The pseudocount added to data, e.g. 0.1 or 0.01
#' @param seed.pca Integer, random seed for PCA reproducibility
#' @param seed.umap Integer, random seed for UMAP reproducibility
#' @param ret.dist Logical, whether return the full distance matrix (often big)
#'
#' @return The return object contains the following components. ctrl.feats: control features, ctrl.mods: control modules, modcount: if impute.ctrl.mods is TRUE then return the imputed module counts, pc.list: list of first 50 PCs by each control module, pc.comb: final PCs combined from the pca.dim1:pca.ndim PCs by each control module, dist: full distance object (optional), umap: umap embedding, graph: nearest-neighbour graph (nn) and shared nearest-neighbour graph (snn), command: command of calling.
#' 
#' @examples
#' \donttest{
#' set.seed(1111)
#' num_genes <- 10000
#' num_samples <- 500
#' counts <- matrix(stats::rpois(num_genes * num_samples, 
#'             lambda = 10), nrow = num_genes, ncol = num_samples)
#' rownames(counts) <- paste0("Gene_", 1:num_genes)
#' colnames(counts) <- paste0("Sample_", 1:num_samples)
#' res = FeatModPairs(counts)
#' }
#' @importFrom stats as.dist cutree loess predict
#' @importFrom utils head
#' 
#' @export
FeatModPairs = function(counts, logcounts=NULL, n.ctrl.feats=100, n.ctrl.mods=20, ctrl.mods=NULL, n.ctrl.nn=30, minsize.ctrl.mod=3, n.var.feats=2000, span=0.3, adjust.modcount=TRUE, adjust.dist.scale=TRUE, impute.ctrl.feats=FALSE, impute.ctrl.mods=FALSE, method.impute='knn', pca=FALSE, pca.ndim=15, pca.dim1=1, pca.scale=FALSE, use.snn=FALSE, k.snn=50, k.impute=10, parallel=TRUE, eps.cnt=0.1, seed.pca=1111, seed.umap=2222, ret.dist=FALSE){
	if(adjust.dist.scale && use.snn){
		stop('Only one of adjust.dist.scale and use.snn can be TRUE.')
	}
	if(pca){
		if(adjust.dist.scale || use.snn){
			adjust.dist.scale = use.snn = FALSE
			warning('Since pca is TRUE, adjust.dist.scale & use.snn are set to FALSE.')
		}
	}
	if(impute.ctrl.feats && impute.ctrl.mods){
		stop('Either ctrl.feats or ctrl.mods could be imputed, you have specified both!')
	}
	if(!is.matrix(counts)){
		counts = data.matrix(counts)
	}
	if(is.null(logcounts)){
		logcounts = log(t(t(counts)/colSums(counts)*1e4) + 1)
	}else{
		if(!is.matrix(logcounts)){
			logcounts = data.matrix(logcounts)
		}
	}
	if(is.null(ctrl.mods)){
		o = order(rowMeans(logcounts),decreasing=TRUE)
		inds.ctrl.feats = head(o,n.ctrl.feats)
		#add ctrl genes' kNN genes
		print('Perform expansion of ctrl genes via kNN ...')
		dmat.ctrl_to_others = Rfast::dista(logcounts[inds.ctrl.feats,],logcounts)
		inds.ctrl.feats = union(inds.ctrl.feats, as.vector(apply(dmat.ctrl_to_others,1,function(x) head(order(x),n.ctrl.nn) )))
		print(sprintf('    %d new genes attracted by ctrl genes', length(inds.ctrl.feats)-n.ctrl.feats))
	}else{
		impute.ctrl.feats = FALSE
		inds.ctrl.feats = match(unique(unlist(ctrl.mods)), rownames(counts))
		n.ctrl.mods = length(ctrl.mods)
	}
	#impute for zeros in ctrl feats (non-zero entries not changed)
	if(impute.ctrl.feats){
		print('Perform imputation on ctrl features ...')
		if(method.impute=='saver'){ #method: SAVER
			lib.sizes = colSums(counts)/1e4
			tX = log(t(counts[inds.ctrl.feats,])/lib.sizes + 1) #cell x gene
			#tX.imp = apply(tX,2,function(y){
			tX.imp = sapply(1:ncol(tX),function(j){
				y = tX[,j]
				#SAVER::expr.predict(x=tX, y=y)[[1]]
				SAVER::expr.predict(x=tX[,-j], y=y)[[1]]
			})
			#back to raw counts
			Xcnt.imp = t( (exp(tX.imp)-1) * lib.sizes )
			#replace 0s but keep other non-zero counts
			counts.ctrl.imp = ifelse(counts[inds.ctrl.feats,]>0, counts[inds.ctrl.feats,], Xcnt.imp) #no round() since imputed raw counts could be in 0~1
			rownames(counts.ctrl.imp) = as.character(inds.ctrl.feats)
		}else if(method.impute=='knn'){ #method: kNN
			lib.sizes = colSums(counts)/1e4
			tX = log(t(counts[inds.ctrl.feats,])/lib.sizes + 1) #cell x gene
			dmat.c = Rfast::Dist(tX)
			dimnames(dmat.c) = list(colnames(counts),colnames(counts))
			nnc.idx = t(apply(dmat.c,1,function(x){ head(x,k.impute+1)[-1] }))
			tX.imp = sapply(1:ncol(tX),function(j){
				y = tX[,j]
				if(any(y==0)){
					inds.0 = which(y==0)
					y[inds.0] = sapply(inds.0,function(ind){ mean(tX[nnc.idx[ind,], j]) })
					y
				}else{
					y
				}
			})
			#back to raw counts
			counts.ctrl.imp = t( (exp(tX.imp)-1) * lib.sizes )
			rownames(counts.ctrl.imp) = as.character(inds.ctrl.feats)
		}else{
			stop("method.impute must be one of: saver, knn")
		}
	}
	#get ctrl modules: use original data even impute.ctrl.feats == TRUE to avoid potential distortions caused by imputation
	if(!is.null(ctrl.mods)){
		print('Using given ctrl modules ...')
		#convert from genes to inds (character)
		ctrl.mods = lapply(ctrl.mods,function(x){ match(x,rownames(counts)) })
	}else{
		print('Get ctrl modules ...')
		dmat.ctrl.feats = Rfast::Dist(logcounts[inds.ctrl.feats,],)
		hc.ctrl.feats = fastcluster::hclust(as.dist(dmat.ctrl.feats), method='ward.D2')
		cl.ctrl.feats = cutree(hc.ctrl.feats, n.ctrl.mods)
		ctrl.mods = tapply(inds.ctrl.feats, cl.ctrl.feats, c)
		ctrl.mods = ctrl.mods[sapply(ctrl.mods,length)>minsize.ctrl.mod]
		n.ctrl.mods = length(ctrl.mods) #update number of mods
	}
	out = list()
	#distances
	dmat.integ = matrix(0,ncol(counts),ncol(counts))
	if(pca){
		#pc.comb = NULL
		out[['pc.list']] = list()
	}
	if(impute.ctrl.mods){
		modcounts = NULL
		modcounts.imp = NULL
	}
	for(i in 1:n.ctrl.mods){
		print(paste(i,paste(rownames(counts)[ctrl.mods[[i]]],collapse=',')))
		if(!impute.ctrl.feats && !impute.ctrl.mods){
			modcount = colSums(counts[ctrl.mods[[i]],])
		}else if(impute.ctrl.feats){
			modcount = colSums(counts.ctrl.imp[as.character(ctrl.mods[[i]]),])
		}else if(impute.ctrl.mods){
			print(sprintf('   Perform imputation on ctrl module %d ...',i))
			lib.sizes = colSums(counts)/1e4
			modcount = colSums(counts[ctrl.mods[[i]],])
			modcount.lognorm = log(modcount/lib.sizes + 1)
			tX = log(t(counts[inds.ctrl.feats,])/lib.sizes + 1) #cell x gene
			modcounts = rbind(modcounts, modcount)
			if(method.impute=='saver'){
				modcount.lognorm.pred = SAVER::expr.predict(x=tX, y=modcount.lognorm)[[1]]
				modcount.pred = (exp(modcount.lognorm.pred)-1) * lib.sizes
				modcount = ifelse(modcount>0, modcount, modcount.pred)
			}else if(method.impute=='knn'){
				#lib.sizes = colSums(counts)/1e4
				#modcount = colSums(counts[ctrl.mods[[i]],])
				#modcount.lognorm = log(modcount/lib.sizes + 1)
				#tX: only logcounts of ctrl.feats
				#tX = log(t(counts[inds.ctrl.feats,])/lib.sizes + 1) #cell x gene
				modcount.pred = modcount
				for(j in which(modcount==0)){
					idx = head(order(Rfast::dista(tX[j,,drop=F], tX, parallel=parallel)[1,]),k.impute+1)[-1]
					modcount.pred[j] = (exp(mean(modcount.lognorm[idx])) - 1) * lib.sizes[j]
				}
				modcount = ifelse(modcount>0, modcount, modcount.pred)
			}else{
				stop("method.impute must be one of: saver, knn")
			}
			modcounts.imp = rbind(modcounts.imp, modcount.pred)
		}else{
			stop('no such condition')
		}
		if(T){
			ratio = t((t(counts)+eps.cnt)/(modcount+eps.cnt)) 
		}else{
			ratio = t(t(counts)/modcount)
		}
		if(adjust.modcount){
			ratio = ratio * mean(modcount) #adjust scale
		}
		
		if(F){
			ratio.z = scale(ratio) 
		}
		#find variable features
		if(F){
			#stat.vst = aux_find_variable_features_vst(ratio.z,eps.var=0.01,std.max=10)
		}else{
			stat.vst = aux_find_variable_features_vst(ratio,eps.var=0.01,span=span)
		}
		var.feats = head(rownames(stat.vst),n.var.feats)
		#dmat = Rfast::Dist(t(scale(ratio)))
		if(pca){
			set.seed(seed.pca)
			ratio.pca = irlba::prcomp_irlba(ratio[var.feats,], n=max(pca.ndim,50), center=TRUE, scale.=pca.scale) #column center
			if(F){
				dmat = Rfast::Dist(ratio.pca$rotation[,pca.dim1:pca.ndim])
			}else{
				#pc.comb = cbind(pc.comb, ratio.pca$rotation[,pca.dim1:pca.ndim])
				out[['pc.list']][[i]] = ratio.pca$rotation #[,pca.dim1:pca.ndim]
			}
		}else{
			if(F){
				dmat = Rfast::Dist(t(ratio.z[var.feats,]))
			}else if(T){
				dmat = Rfast::Dist(t(ratio[var.feats,]))
			}
		}
		if(adjust.dist.scale){
			dmat = matrixStats::colRanks(dmat,ties.method='average',preserveShape=T)/nrow(dmat)
		}
		#SNN to automatically adjust to comparable scale
		if(use.snn){
			dmat = 1 - data.matrix(Seurat::FindNeighbors(dmat, distance.matrix=TRUE, nn.method = "annoy", k.param=k.snn, prune.SNN=0, return.neighbor=FALSE)$snn)
		}
		if(adjust.dist.scale || use.snn){
			dmat.integ = dmat.integ + dmat 
		}else if(!pca){
			dmat.integ = dmat.integ + log(dmat) 
		}
		#res.umap = uwot::umap(as.dist(dmat))
	}
	if(adjust.dist.scale || use.snn){
		dmat.integ = dmat.integ/n.ctrl.feats 
	}else{
		dmat.integ = exp(dmat.integ/n.ctrl.feats) 
	}
	if(adjust.dist.scale){
		#from distance ranks, calculate Euclidean distance matrix
		dmat.integ = Rfast::Dist(dmat.integ)
	}
	if(pca){
		pc.comb = do.call(cbind, lapply(out[['pc.list']], function(x) x[,pca.dim1:pca.ndim]))
		dmat.integ = Rfast::Dist(pc.comb)
	}

	diag(dmat.integ) = 0
	dimnames(dmat.integ) = list(colnames(counts),colnames(counts))

	#for use in integration with other datasets
	if(is.null(ctrl.mods)){
		#attr(dmat.integ, 'ctrl.feats') = rownames(counts)[inds.ctrl.feats]
		out[['ctrl.feats']] = rownames(counts)[inds.ctrl.feats]
	}
	#attr(dmat.integ, 'ctrl.mods') = lapply(ctrl.mods,function(inds) rownames(counts)[inds])
	out[['ctrl.mods']] = lapply(ctrl.mods,function(inds) rownames(counts)[inds])
	if(impute.ctrl.mods){
		#attr(dmat.integ, 'modcounts.imp') = modcounts.imp
		#attr(dmat.integ, 'modcounts') = modcounts
		out[[modcounts.imp]] = modcounts.imp
		out[['modcounts']] = modcounts
	}
	if(pca){
		#attr(dmat.integ, 'pc.comb') = pc.comb
		#out[['pc.list']] = pc.list
		out[['pc.comb']] = pc.comb
	}

	dist.integ = as.dist(dmat.integ)
	if(ret.dist){ out[['dist']] = dist.integ }
	res.umap = uwot::umap(dist.integ, seed=seed.umap)
	#attr(dmat.integ,'umap') = res.umap
	out[['umap']] = res.umap
	res.nn = Seurat::FindNeighbors(dist.integ,k.param = 20,prune.SNN = 1/15,n.trees = 50,nn.method = "rann",compute.SNN=TRUE) #rann is exact NN, not approximate
	out[['graph']] = res.nn
	out[['command']] = sys.call(0)
	return(out)
}



